# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['photo_classifier']

package_data = \
{'': ['*']}

install_requires = \
['fire>=0.4.0,<0.5.0']

entry_points = \
{'console_scripts': ['photo-classifier = photo_classifier.command:main']}

setup_kwargs = {
    'name': 'photo-classifier',
    'version': '0.0.1',
    'description': 'Extract data from your photos and show photos on map where taken',
    'long_description': None,
    'author': 'Damian Ziobro',
    'author_email': 'damian@xmementoit.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
